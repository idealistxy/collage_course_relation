#include <ros/ros.h>
#include <geometry_msgs/PointStamped.h>
#include <cmath>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "circle_publisher");
    ros::NodeHandle nh;

    ros::Publisher pub = nh.advertise<geometry_msgs::PointStamped>("circle_point", 10);
    ros::Rate loop_rate(30); // 设置频率为30Hz

    double radius = 2.0; // 圆的半径
    double angle = 0.0; // 初始角度
    double angle_increment = M_PI / 30; // 每次增加的角度，这里简单设为π/5，可以根据需要调整

    ROS_INFO("Start publishing circle points.");

    while (ros::ok())
    {
        geometry_msgs::PointStamped point;
        point.header.stamp = ros::Time::now();
        point.header.frame_id = "world";

        // 根据圆的参数方程计算点的坐标
        point.point.x = radius * cos(angle);
        point.point.y = radius * sin(angle);
        point.point.z = 0.0;

        pub.publish(point);

        angle += angle_increment;
        if (angle >= 2 * M_PI)
        {
            angle -= 2 * M_PI; // 保持角度在0到2π之间
        }

        ros::spinOnce();
        loop_rate.sleep();
    }

    return 0;
}