#include <ros/ros.h>
#include <geometry_msgs/PointStamped.h>
#include <visualization_msgs/Marker.h>

ros::Publisher marker_pub;

void circlePointCallback(const geometry_msgs::PointStamped::ConstPtr& msg)
{
    visualization_msgs::Marker marker;

    // TODO: 配置Marker基本属性

    // TODO：设置Marker的视觉属性

    // TODO: 添加点到Marker

    // 发布marker
    marker_pub.publish(marker);
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "circle_visualizer");
    ros::NodeHandle n;

    marker_pub = n.advertise<visualization_msgs::Marker>("circle_visualization_marker", 10);
    ros::Subscriber sub = n.subscribe("circle_point", 10, circlePointCallback);

    ros::spin();
}