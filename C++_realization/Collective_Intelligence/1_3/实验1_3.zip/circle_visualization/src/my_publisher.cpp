#include <ros/ros.h>

int main(int argc, char** argv)
{
    // TODO: 实现你自己的发布者
    return 0;
}